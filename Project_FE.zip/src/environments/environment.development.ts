export const environment = {
  production: false,
  baseUrl: 'http://172.16.238.165:8080',
};