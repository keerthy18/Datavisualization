package com.maveric.datavisualization.dtos.dtos;

public enum KYCStatus {

    PENDING,
    VERIFIED,
    REJECTED,
    UNDER_REVIEW
}
