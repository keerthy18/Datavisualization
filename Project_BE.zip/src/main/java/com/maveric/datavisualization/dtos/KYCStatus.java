package com.maveric.datavisualization.dtos;

public enum KYCStatus {

    PENDING,
    VERIFIED,
    REJECTED,
    UNDER_REVIEW
}
